/** Automatically generated file. DO NOT MODIFY */
package com.cindy.cindymessage;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}