
public class NQueen {
	private void createBoard{
		;
	}
}
