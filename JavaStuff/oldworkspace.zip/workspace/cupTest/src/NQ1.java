
public class NQ1 {

}
