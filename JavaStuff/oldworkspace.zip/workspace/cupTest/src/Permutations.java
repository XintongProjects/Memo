/*************************************************************************
 *  Compilation:  javac Permutations.java
 *  Execution:    java Permutations N
 *  
 *  Enumerates all permutations on N elements.
 *  Two different approaches are included.
 *
 *  % java Permutations 3
 *  abc
 *  acb
 *  bac 
 *  bca
 *  cab
 *  cba
 *
 *************************************************************************/
public class Permutations {

    // print N! permutation of the characters of the string s (in order)
    public  static void perm1(String s) { perm1("", s); }
    private static void perm1(String prefix, String s) {
        int N = s.length();
        if (N == 0) System.out.println(prefix);
        else {
            for (int i = 0; i < N; i++)
               perm1(prefix + s.charAt(i), s.substring(0, i) + s.substring(i+1, N));
        }

    }

    // print N! permutation of the elements of array a (not in order)
    public static void perm2(String s) {
       int N = s.length();
       char[] a = new char[N];
       for (int i = 0; i < N; i++)
           a[i] = s.charAt(i);
       perm2(a, N);
    }

    private static void perm2(char[] a, int n) {
        if (n == 1) {
            System.out.println(a);
            return;
        }
        for (int i = 0; i < n; i++) {
            swap(a, i, n-1);
            perm2(a, n-1);
            swap(a, i, n-1);
        }
    }  

    // swap the characters at indices i and j
    private static void swap(char[] a, int i, int j) {
        char c;
        c = a[i]; a[i] = a[j]; a[j] = c;
    }


	private static void initializeMatrix(int[][] a){
		int row = a.length;
		int col = a[0].length;
		  
    	for (int i = 0; i < row; i++){
    		for (int j = 0; j < col; j++){
    			a[i][j] = 0;
    		}
    	}  	
    }
	
	// total unique paths
	private static void printMatrix(int[][] a){
		int row = a.length;
		int col = a[0].length;
		  
    	for (int i = 0; i < row; i++){
    		for (int j = 0; j < col; j++){
    			System.out.print(a[i][j] + " ");
    		}
    		System.out.println();
    	}  	
    }

	public static int totalPath(int n, int m){
		int total = 0;
		int map[][] = new int [n][m];
		for (int i = n-1; i >= 0; i--)
			map[i][m-1] = 1;
		
		for (int i = m-1; i >= 0; i--)
			map[n-1][i] = 1;
		
		for (int i = n-2; i >=0; i--){
			for (int j = m-2; j >= 0; j--){
				map[i][j] = map[i+1][j] + map[i][j+1];			
			}
		}
		
		total = map[0][0];
		return total;
	}
	
	
    public static void main(String[] args) {
       int N = 5;//Integer.parseInt(args[0]);
       String alphabet = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
       String elements = alphabet.substring(0, N);
       perm1(elements);
       System.out.println();
       //perm2(elements);
       int[][] chessboard = new int [8][8];
       initializeMatrix(chessboard);
       printMatrix(chessboard);
       
       int[][] foo = new int[][] {
    		   new int[] { 1, 2, 3 },
    		   new int[] { 4, 5, 6, 7},
       };

       printMatrix(foo);
       System.out.println(foo.length); //2
       System.out.println(foo[0].length); //3
       System.out.println(foo[1].length); //4
       
       
       String Str = new String("Welcome to Tutorialspoint.com");

       System.out.print("Return Value :" );
       System.out.println(Str.substring(8) );

       System.out.print("Return Value :" );
       System.out.println(Str.substring(8, 15) );
       
       System.out.println(Integer.MAX_VALUE + 1);
    	    
    }
	
	
}
