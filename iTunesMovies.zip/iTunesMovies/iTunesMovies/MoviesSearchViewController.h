//
//  MoviesSearchViewController.h
//  iTunesMovies
//
//  Created by Cindy Bi on 1/18/16.
//  Copyright © 2016 Xintong Bi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MoviesSearchViewController : UIViewController <UISearchBarDelegate,
UITableViewDelegate,UITableViewDataSource>


@property (weak, nonatomic) IBOutlet UISearchBar *movieSearchBar;
@property (weak, nonatomic) IBOutlet UITableView *movieTable;
@property (nonatomic, strong) NSMutableArray *moviesList;
@property (nonatomic, strong) NSString *queryString;

@end

