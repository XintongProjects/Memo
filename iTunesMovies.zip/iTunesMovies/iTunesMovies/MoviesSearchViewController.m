//
//  FirstViewController.m
//  iTunesMovies
//
//  Created by Cindy Bi on 1/18/16.
//  Copyright © 2016 Xintong Bi. All rights reserved.
//

#import "MoviesSearchViewController.h"
#import "MovieTableViewCell.h"
#import "MovieDetailsViewController.h"
#import "CommonUtilities.h"

#define movieSearchRootUrl @"https://itunes.apple.com/search?media=movie&term="

@interface MoviesSearchViewController ()

@end

@implementation MoviesSearchViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.navigationController.navigationBar.translucent = NO;
    self.title = NSLocalizedString(@"Title_Search", @"");
    [[self.tabBarController.tabBar.items objectAtIndex:1] setTitle:NSLocalizedString(@"Title_Favorite", @"comment")];
    self.movieSearchBar.delegate = self;
    self.movieSearchBar.showsCancelButton = YES;
    self.movieTable.delegate = self;
    self.movieTable.dataSource = self;
    //    [self.movieTable registerNib:[UINib nibWithNibName:@"MovieTableViewCell" bundle:nil ] forCellReuseIdentifier:@"MovieTableViewCell"];

    UIView* view= self.movieSearchBar.subviews[0];
    for (UIView *subView in view.subviews) {
        if ([subView isKindOfClass:[UIButton class]]) {
            UIButton *cancelButton = (UIButton*)subView;
            NSString *cancelTitle = NSLocalizedString(@"Cancel", @"comment");
            [cancelButton setTitle:cancelTitle forState:UIControlStateNormal];
        }
    }
    self.movieTable.estimatedRowHeight = 180.0;
    self.movieTable.rowHeight = UITableViewAutomaticDimension;
    self.movieTable.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 9.0){
        self.movieTable.cellLayoutMarginsFollowReadableWidth = NO;
    }
    [self.movieTable reloadData];
}

- (void)viewWillAppear {
    [super viewWillAppear:YES];
    //    self.movieTable.estimatedRowHeight = 180.0;
    //    self.movieTable.rowHeight = UITableViewAutomaticDimension;
    self.movieTable.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
}

//User tapped on the cancel button
- (void)searchBarCancelButtonClicked:(UISearchBar *) searchBar {
    DLog(@"User canceled search");
    [searchBar resignFirstResponder];
}

//Search button was tapped
- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar {
    [self handleSearch:searchBar];
}

//User finished editing the search text
- (void)searchBarTextDidEndEditing:(UISearchBar *)searchBar {
    [self handleSearch:searchBar];
}

//Search on the remote server using HTTP request
- (void)handleSearch:(UISearchBar *)searchBar {
    
    //check what was passed as the query String and get rid of the keyboard
    self.queryString = searchBar.text;
    
    [searchBar resignFirstResponder];
    NSString *movieSearchUrl = [movieSearchRootUrl stringByAppendingString:self.queryString];
    //TODO more error handling on user input. + make a seperate utility methods, + unit test it
    movieSearchUrl = [movieSearchUrl stringByReplacingOccurrencesOfString:@" " withString:@"+"];
    
    DLog(@"movieSearchUrl is %@", movieSearchUrl);
    NSURLSession *session = [NSURLSession sharedSession];
    [[session dataTaskWithURL:[NSURL URLWithString:movieSearchUrl] completionHandler:^(NSData * data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        if (error.code == -1009){
            dispatch_async(dispatch_get_main_queue(), ^{
                [self showAlert:NSLocalizedString(@"InternetError", @"comment")
                    withMessage:NSLocalizedString(@"No_internet_connection", @"comment")
                 preferredStyle:UIAlertControllerStyleAlert];
            });     
        }
        
        DLog(@"Response data is %@", [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding]);
        if ([data length] >0 && error == nil){
            [self parseResponse:data];
        }
        else if ([data length] == 0 && error == nil){
            DLog(@"Empty Response");
        }
        else if (error != nil){
            DLog(@"The error is= %@", error);
        }
        
    }] resume];
}

//parse our JSON response from the server
- (void)parseResponse:(NSData *) data {
    
    NSString *myData = [[NSString alloc] initWithData:data
                                             encoding:NSUTF8StringEncoding];
    DLog(@"JSON data = %@", myData);
    NSError *error = nil;
    
    id jsonObject = [NSJSONSerialization
                     JSONObjectWithData:data
                     options:NSJSONReadingAllowFragments
                     error:&error];
    if (jsonObject != nil && error == nil){
        self.moviesList = [jsonObject objectForKey:@"results"];
        NSLog(@"total count is %lu", (unsigned long)[self.moviesList count]);
        dispatch_async(dispatch_get_main_queue(), ^{
            if ([self.moviesList count] <= 0){
                [self showAlert:NSLocalizedString(@"No_match_found", @"comment") withMessage:NSLocalizedString(@"Try_another_search_term", @"comment")
                 preferredStyle:UIAlertControllerStyleAlert];
                
            }
            else{
                [self.movieTable reloadData];
                
            }
        });
    }
    else{
        //TODO display error
    }
}

//number of rows in a given section of a table view
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.moviesList.count;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return UITableViewAutomaticDimension;
}

//asks the data source for a cell to insert in a particular location of the table view
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{

    static NSString *identifier = @"MovieTableViewCell";
    MovieTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell == nil){
        [tableView registerNib:[UINib nibWithNibName:@"MovieTableViewCell" bundle:nil] forCellReuseIdentifier:identifier];
        cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    }

    //if there are movies to display
    if(self.moviesList.count > 0){
        NSMutableDictionary *movieInfo = [self.moviesList objectAtIndex:indexPath.row];
        cell.postImageView.image = [UIImage imageNamed:@"placeholder.png"];
        cell.movieNameLbl.text = @"Unknown movie name";
        cell.artistNameLbl.text = @"Unknown artist";
        
        cell.movieNameLbl.text = movieInfo[@"trackName"];
        cell.artistNameLbl.text = movieInfo[@"artistName"];
        cell.descriptionLbl.text = [movieInfo valueForKey:@"shortDescription"];
        NSString * dateStr = [movieInfo valueForKey:@"releaseDate"];
        cell.yearLbl.text = [CommonUtilities getYearStringFromInput:dateStr];
        NSURL *imageURL = [NSURL URLWithString:[movieInfo valueForKey:@"artworkUrl100"]];
        //dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0ul);
        dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0ul);
        dispatch_async(queue, ^{
            NSData *data = [NSData dataWithContentsOfURL : imageURL];
            
            dispatch_async(dispatch_get_main_queue(), ^{
                
                cell.postImageView.image = [UIImage imageWithData:data];
                [cell setNeedsLayout];
            });
        });
    }
//    else {
//        cell.movieNameLbl.text = @"No Results found, try again!";
//        cell.descriptionLbl.text = @"";
//    }
//    
    //set the table view cell style
    [cell setSelectionStyle:UITableViewCellSelectionStyleDefault];
    [cell layoutIfNeeded];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    MovieDetailsViewController *detailview = [[MovieDetailsViewController alloc] initWithNibName:@"MovieDetailsViewController" bundle:nil];
    NSDictionary *movieInfo = [self.moviesList objectAtIndex:indexPath.row];
    detailview.movieDict = [NSDictionary dictionaryWithDictionary:movieInfo];
    [self.navigationController pushViewController:detailview animated:YES];
}

//Display a generic alert

-(void)showAlert: (NSString *) title withMessage: (NSString*) message preferredStyle:(UIAlertControllerStyle)preferredStyle
{
    
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *ok =[UIAlertAction actionWithTitle:NSLocalizedString(@"OK", @"comment") style:UIAlertActionStyleDefault handler:^(UIAlertAction *action)
                        {NSLog(@"ok action");}];
    [alert addAction:ok];
    [self presentViewController:alert animated:YES completion:nil];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
    [self.moviesList removeAllObjects];
}

@end
