//
//  CommonUtilities.h
//  iTunesMovies
//
//  Created by Cindy Bi on 1/19/16.
//  Copyright © 2016 Xintong Bi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CommonUtilities : NSObject

+ (NSString*)getYearStringFromInput: (NSString*) inputStr;
+ (BOOL)image:(UIImage *)image1 isEqualTo:(UIImage *)image2;
@end
