//
//  CommonUtilities.m
//  iTunesMovies
//
//  Created by Cindy Bi on 1/19/16.
//  Copyright © 2016 Xintong Bi. All rights reserved.
//

#import "CommonUtilities.h"

@implementation CommonUtilities

// get the firs 4 digits that represents year.
+ (NSString*)getYearStringFromInput: (NSString*) inputStr{
    // input string example: "1989-04-21T07:00:00Z". TODO put in unit test
    NSString * result = @"";
    if (inputStr.length >= 4){
        result =[inputStr substringToIndex:4];
    }
    return result;
}

+ (BOOL)image:(UIImage *)image1 isEqualTo:(UIImage *)image2
{
    NSData *data1 = UIImagePNGRepresentation(image1);
    NSData *data2 = UIImagePNGRepresentation(image2);
    
    return [data1 isEqual:data2];
}

@end
