//
//  MovieDetailsViewController.h
//  iTunesMovies
//
//  Created by Cindy Bi on 1/19/16.
//  Copyright © 2016 Xintong Bi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MovieDetailsViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIImageView *postImageView;
@property (weak, nonatomic) IBOutlet UIImageView *favoriteIconView;
@property (weak, nonatomic) IBOutlet UITextView *longDescriptionTextView;
@property (strong, nonatomic) NSDictionary *movieDict;
@property (assign, nonatomic) BOOL isFavorite;
@property (weak, nonatomic) IBOutlet UIButton *favoriteBtn;

- (IBAction)toggleFavoriteBtn:(id)sender;

@end
