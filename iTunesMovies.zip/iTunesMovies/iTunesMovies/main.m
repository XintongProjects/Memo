//
//  main.m
//  iTunesMovies
//
//  Created by Cindy Bi on 1/18/16.
//  Copyright © 2016 Xintong Bi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
