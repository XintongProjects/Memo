//
//  MovieTableViewCell.m
//  iTunesMovies
//
//  Created by Cindy Bi on 1/18/16.
//  Copyright © 2016 Xintong Bi. All rights reserved.
//

#import "MovieTableViewCell.h"

@implementation MovieTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
