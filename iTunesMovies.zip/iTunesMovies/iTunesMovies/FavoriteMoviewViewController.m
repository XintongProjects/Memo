//
//  SecondViewController.m
//  iTunesMovies
//
//  Created by Cindy Bi on 1/18/16.
//  Copyright © 2016 Xintong Bi. All rights reserved.
//

#import "FavoriteMoviewViewController.h"

@interface FavoriteMoviewViewController ()

@end

@implementation FavoriteMoviewViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
