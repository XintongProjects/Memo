//
//  MovieDetailsViewController.m
//  iTunesMovies
//
//  Created by Cindy Bi on 1/19/16.
//  Copyright © 2016 Xintong Bi. All rights reserved.
//

#import "MovieDetailsViewController.h"

@interface MovieDetailsViewController ()

@end

@implementation MovieDetailsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.longDescriptionTextView.text = [self.movieDict valueForKey:@"longDescription"];
    NSURL *imageURL = [NSURL URLWithString:[self.movieDict valueForKey:@"artworkUrl100"]]; //"previewUrl"
    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0ul);
    dispatch_async(queue, ^{
        NSData *data = [NSData dataWithContentsOfURL : imageURL];
        
        dispatch_async(dispatch_get_main_queue(), ^{
            
            self.postImageView.image = [UIImage imageWithData:data];
        });
    });
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)toggleFavoriteBtn:(id)sender {
    self.isFavorite = !self.isFavorite;
    [self.favoriteBtn setImage:[UIImage imageNamed:self.isFavorite ? @"heart_red.png" :@"heart_black.png"] forState:UIControlStateNormal];
}
@end
